# suite.pm
#
# MyVector test suite
#
package My::Suite::MyVector;
use strict;
use warnings;
use My::Suite;
our @ISA = qw(My::Suite);
sub suite_name { 'myvector' }
1;
